/* FCAI – OOP Programming – 2023 - Assignment 1
 Program Name:				OOP_PROJECT.cpp
 Last Modification Date:	9/10/2023
 Author1 and ID and Group:	Abdelrahman Hossam Abdelrahman Farag 20221095
 Author2 and ID and Group:	Youssef Nabil Ismail waer  20221205
 Author3 and ID and Group:  Mohamed Ahmed Abdelsamad Sayed
 Teaching Assistant:		xxxxx xxxxx
 Purpose: Make filters for gray images
*/

#include <iostream>
#include <fstream>
#include <cstring>
#include <cmath>
#include "bmplib.cpp"
#include "bmplib.h"

using namespace std;
unsigned char image[SIZE][SIZE];
unsigned char image1[SIZE][SIZE];
unsigned char image2[SIZE][SIZE];

void loadImage();
void Darken_Lighten();
void rotate();
void merge();
void flip();
void black_white();
void inverse();
void saveImage();

int main() {
    char choice;

    cout << "Image Processing Menu:" << endl;
    cout << "1 - Black & White Filter" << endl;
    cout << "2 - Invert Filter" << endl;
    cout << "3 - Merge Filter" << endl;
    cout << "4 - Flip Image" << endl;
    cout << "5 - Darken and Lighten Image" << endl;
    cout << "6 - Rotate Image" << endl;
    cout << "Enter your choice (1-6): ";
    cin >> choice;

    switch (choice) {
        case '1':
            black_white();
            break;
        case '2':
            inverse();
            break;
        case '3':
            merge();
            break;
        case '4':
            flip ();
            break;
        case '5':
            Darken_Lighten ();
            break;
        case '6':
            rotate();
            break;
        default:
            cout << "Invalid choice. Please select a valid option." << endl;
            return 1;
    }

    saveImage();
    return 0;
}

void loadImage () {
    char imageFileName[100];

    // Get gray scale image file name
    cout << "Enter the source image file name: ";
    cin >> imageFileName;

    // Add to it .bmp extension and load image
    strcat (imageFileName, ".bmp");
    readGSBMP(imageFileName, image);
}

//_________________________________________
void saveImage () {
    char imageFileName[100];

    // Get gray scale image target file name
    cout << "Enter the target image file name: ";
    cin >> imageFileName;

    // Add to it .bmp extension and load image
    strcat (imageFileName, ".bmp");
    writeGSBMP(imageFileName, image);

}
void black_white() {
    loadImage();
    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j< SIZE; j++)
        {
            if (image[i][j] > 127)
            {
                image[i][j] = 255;
            }
            else
                image[i][j] = 0;
        }
    }
}
void inverse() {
    loadImage();
    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j< SIZE; j++)
        {
            image[i][j] = 255 - image[i][j] ;
        }
    }
}
void merge() {
    char imageFileName[100];

    // Get gray scale image file name
    cout << "Enter the source image file name: ";
    cin >> imageFileName;

    // Add to it .bmp extension and load image
    strcat (imageFileName, ".bmp");
    readGSBMP(imageFileName, image1);


    // Get gray scale image file name
    cout << "Enter the source image file name: ";
    cin >> imageFileName;

    // Add to it .bmp extension and load image
    strcat (imageFileName, ".bmp");
    readGSBMP(imageFileName, image2);

    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j< SIZE; j++)
        {

            image[i][j] = (image1[i][j] + image2[i][j])/2;
        }
    }
}
void flip(){
    char imageFileName[100];
    cout << "Enter 0 for Horizontal ,Enter 1 for Vertecal : " ;
    int n;
    cin >> n;
    // Get gray scale image file name
    cout << "Enter the source image file name: ";
    cin >> imageFileName;

    // Add to it .bmp extension and load image
    strcat (imageFileName, ".bmp");
    readGSBMP(imageFileName, image1);



    if(n){
        for(int i = 0;i < SIZE;i++){
            for(int j = 0;j < SIZE;j++)
            {
                image2[i][j] = image1[SIZE-i][SIZE-j];
            }
        }
        for(int i = 0;i < SIZE;i++){
            for(int j = 0;j < SIZE;j++)
            {
                image[i][j] = image2[i][SIZE-j];
            }
        }
    }
    else{
        for(int i = 0;i < SIZE;i++){
            for(int j = 0;j < SIZE;j++)
            {
                image[i][j] = image1[i][SIZE-j];
            }
        }
    }
}

void rotate (){
    char imageFileName[100];

    // Get gray scale image file name
    cout << "Enter the source image file name: ";
    cin >> imageFileName;

    // Add to it .bmp extension and load image
    strcat (imageFileName, ".bmp");
    readGSBMP(imageFileName, image1);
    cout << "Enter the degree you want to rotate(90, 180, 270) : \n";
    int n;
    cin >> n;
    switch(n){
        case 90:{
            for(int i = 0;i < SIZE;i++)
            {
                for(int j = 0;j < SIZE;j++)
                {
                    image[i][SIZE-j] = image1[j][i];
                }
            }
            break;
        }
        case 180:{
            for(int i = 0;i < SIZE;i++)
            {
                for(int j = 0;j < SIZE;j++)
                {
                    image[i][j] = image1[SIZE-i][SIZE-j];
                }
            }
            break;
        }
        case 270: {
            for(int i = 0;i < SIZE;i++)
            {
                for(int j = 0;j < SIZE;j++)
                {
                    image2[SIZE-j][SIZE-i] = image1[i][j];
                }
            }
            for(int i = 0;i < SIZE;i++)
            {
                for(int j = 0;j < SIZE;j++)
                {
                    image[SIZE-i][j] = image2[SIZE-i][SIZE-j];
                }
            }
        }
    }
}
void Darken_Lighten ()
{
    loadImage();
    int n;
    cout << "For dark enter 0 for light enter 1 : ";
    cin >> n;
    if(!n) {
        for(int i = 0;i < SIZE;i++){
            for(int j = 0;j < SIZE;j++)
            {
                image[i][j] *= 0.5;
            }
        }
    }
    else{
        for(int i = 0;i < SIZE;i++){
            for(int j = 0;j < SIZE;j++)
            {
                image[i][j] = (image[i][j]+255) / 2;
            }
        }
    }
}